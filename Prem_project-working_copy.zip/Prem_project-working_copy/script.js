function onlinePay() {
  var options = {
    "key": "rzp_test_123456789",  // Razorpay Test Key
    "amount": 49900,
    "currency": "INR",
    "name": "Life Tees",
    "description": "T-Shirt Purchase",
    "handler": function (response) {
      window.location.href = "success.html";
    },
    "theme": {
      "color": "#000"
    }
  };
  var rzp = new Razorpay(options);
  rzp.open();
}

function codOrder() {
  alert("Order placed successfully (Cash on Delivery)");
  window.location.href = "success.html";
}

function validateForm() {
  if (
    document.getElementById("name").value == "" ||
    document.getElementById("phone").value == "" ||
    document.getElementById("address").value == "" ||
    document.getElementById("pincode").value == ""
  ) {
    alert("Please fill all details");
    return false;
  }
  return true;
}

function onlinePay() {
  if (!validateForm()) return;

  var options = {
    "key": "rzp_test_123456789",   // CHANGE TO YOUR KEY
    "amount": 49900,
    "currency": "INR",
    "name": "Life Tees",
    "description": "T-Shirt Order",
    "handler": function () {
      window.location.href = "success.html";
    }
  };

  var rzp = new Razorpay(options);
  rzp.open();
}

function codOrder() {
  if (!validateForm()) return;

  alert("Order placed successfully (Cash on Delivery)");
  window.location.href = "success.html";
}

function sendWhatsAppOrder() {
  var name = document.getElementById("name").value;
  var phone = document.getElementById("phone").value;
  var address = document.getElementById("address").value;
  var pincode = document.getElementById("pincode").value;

  var message =
    "NEW ORDER%0A" +
    "Name: " + name + "%0A" +
    "Phone: " + phone + "%0A" +
    "Address: " + address + "%0A" +
    "Pincode: " + pincode + "%0A" +
    "Product: T-Shirt%0A" +
    "Amount: ₹499";

  var whatsappNumber = "91XXXXXXXXXX"; // 👉 YOUR NUMBER
  window.open("https://wa.me/" + whatsappNumber + "?text=" + message, "_blank");
}

function codOrder() {
  if (!validateForm()) return;
  sendWhatsAppOrder();
  window.location.href = "success.html";
}

function downloadInvoice() {
  const { jsPDF } = window.jspdf;
  var doc = new jsPDF();

  doc.text("Life Tees - Invoice", 20, 20);
  doc.text("Product: T-Shirt", 20, 40);
  doc.text("Price: ₹499", 20, 50);
  doc.text("Payment: COD / Online", 20, 60);
  doc.text("Thank you for shopping!", 20, 80);

  doc.save("LifeTees-Invoice.pdf");
}

function adminLogin(){
 firebase.auth().signInWithEmailAndPassword(
  document.getElementById("email").value,
  document.getElementById("password").value
 ).then(()=>window.location="dashboard.html");
}

fetch("https://www.fast2sms.com/dev/bulkV2",{
 headers:{authorization:"API_KEY"},
 body: JSON.stringify({ numbers: phone, message:"Order confirmed" })
})

doc.text("GSTIN: 33ABCDE1234F1Z5",20,30);
doc.text("HSN: 6109",20,40);
doc.text("CGST 2.5%: ₹12.47",20,50);
doc.text("SGST 2.5%: ₹12.47",20,60);
doc.text("Total: ₹499",20,70);

const canvas = document.getElementById("star-bg");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let stars = [];
for (let i = 0; i < 100; i++) {
  stars.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 2 + 1,
    d: Math.random() * 0.5
  });
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < stars.length; i++) {
    ctx.beginPath();
    ctx.arc(stars[i].x, stars[i].y, stars[i].r, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.fill();
  }
  move();
}

let angle = 0;
function move() {
  angle += 0.01;
  for (let i = 0; i < stars.length; i++) {
    stars[i].x += Math.sin(angle) * 0.5;
    stars[i].y += Math.cos(angle) * 0.5;
    if (stars[i].x > canvas.width) stars[i].x = 0;
    if (stars[i].x < 0) stars[i].x = canvas.width;
    if (stars[i].y > canvas.height) stars[i].y = 0;
    if (stars[i].y < 0) stars[i].y = canvas.height;
  }
}

setInterval(draw, 30);

window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

const canvas = document.getElementById("tee-canvas");
const ctx = canvas.getContext("2d");

function resize(){
  canvas.width = innerWidth;
  canvas.height = innerHeight;
}
resize(); addEventListener("resize", resize);

const img = new Image();
img.src = "https://picsum.photos/120/160?random=20"; // tee icon

const tees = Array.from({length:18}, ()=>({
  x: Math.random()*canvas.width,
  y: Math.random()*canvas.height,
  s: 0.5+Math.random(),
  v: 0.3+Math.random()
}));

function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  tees.forEach(t=>{
    ctx.drawImage(img, t.x, t.y, 120*t.s, 160*t.s);
    t.y -= t.v;
    if(t.y < -200) t.y = canvas.height+50;
  });
  requestAnimationFrame(draw);
}
img.onload = draw;

const men = document.querySelectorAll('.men');
const women = document.querySelectorAll('.women');
const tabs = document.querySelectorAll('.tab');

function showMen(){
  men.forEach(p => p.style.display = "block");
  women.forEach(p => p.style.display = "none");
  tabs[0].classList.add("active");
  tabs[1].classList.remove("active");
}

function showWomen(){
  women.forEach(p => p.style.display = "block");
  men.forEach(p => p.style.display = "none");
  tabs[1].classList.add("active");
  tabs[0].classList.remove("active");
}

/* default */
showMen();

<script>
/* MEN PAGE */
function goMen(){
  window.location.href = "men.html";
}

/* WOMEN PAGE */
function goWomen(){
  window.location.href = "women.html";
}

/* SEARCH FUNCTION */
function searchProduct(){
  var input = document.getElementById("searchInput").value.toLowerCase();
  var products = document.getElementsByClassName("product");

  for(var i = 0; i < products.length; i++){
    var name = products[i].getAttribute("data-name");

    if(name.includes(input)){
      products[i].style.display = "block";
    }else{
      products[i].style.display = "none";
    }
  }
}
</script>




