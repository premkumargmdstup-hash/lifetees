/* =====================
   FORM VALIDATION
===================== */
function validateForm() {
  if (
    document.getElementById("name").value === "" ||
    document.getElementById("phone").value === "" ||
    document.getElementById("address").value === "" ||
    document.getElementById("pincode").value === ""
  ) {
    alert("Please fill all details");
    return false;
  }
  return true;
}

/* =====================
   ONLINE PAYMENT
===================== */
function onlinePay() {
  if (!validateForm()) return;

  var options = {
    key: "rzp_test_123456789",
    amount: 49900,
    currency: "INR",
    name: "Life Tees",
    description: "T-Shirt Order",
    handler: function () {
      window.location.href = "success.html";
    },
    theme: { color: "#000" }
  };

  var rzp = new Razorpay(options);
  rzp.open();
}

/* =====================
   COD ORDER
===================== */
function codOrder() {
  if (!validateForm()) return;
  sendWhatsAppOrder();
  window.location.href = "success.html";
}

/* =====================
   WHATSAPP ORDER
===================== */
function sendWhatsAppOrder() {
  var name = document.getElementById("name").value;
  var phone = document.getElementById("phone").value;
  var address = document.getElementById("address").value;
  var pincode = document.getElementById("pincode").value;

  var msg =
    "NEW ORDER%0A" +
    "Name: " + name + "%0A" +
    "Phone: " + phone + "%0A" +
    "Address: " + address + "%0A" +
    "Pincode: " + pincode + "%0A" +
    "Product: T-Shirt%0A" +
    "Amount: ₹499";

  window.open("https://wa.me/91XXXXXXXXXX?text=" + msg, "_blank");
}

/* =====================
   MEN / WOMEN PAGE
===================== */
function goMen() {
  window.location.href = "men.html";
}
function goWomen() {
  window.location.href = "women.html";
}

/* =====================
   SEARCH PRODUCT
===================== */
function searchProduct() {
  var input = document.getElementById("searchInput").value.toLowerCase();
  var products = document.getElementsByClassName("product");

  for (let i = 0; i < products.length; i++) {
    let name = products[i].dataset.name.toLowerCase();
    products[i].style.display = name.includes(input) ? "block" : "none";
  }
}
